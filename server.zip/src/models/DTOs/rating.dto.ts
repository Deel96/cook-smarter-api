export interface  RatingDTO{
    id:number,
    author: string,
    stars: number;
}