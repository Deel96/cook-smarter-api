export class  GrocerylistUpdateDTO{
    id:number;
    checked:boolean;
}