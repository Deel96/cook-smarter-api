export class  CommentDTO{
    id: number;
    text:string;
    authorId: number;
    date: Date;
}