export interface SucessResponseDTO{
    message: string;
}