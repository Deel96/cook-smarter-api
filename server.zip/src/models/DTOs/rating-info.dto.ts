export interface  RatingInfoDTO{
    stars: number;
    votes: number;
}