export interface  TagDTO{
    id:number;
    name?: string;
    description?:string;
}