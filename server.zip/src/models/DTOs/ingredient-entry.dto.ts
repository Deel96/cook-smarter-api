export interface IngredientEntryDTO {
    id?: number;
    name:string
    amount: number;
    unit: string;
    freshness: string;
}
    